<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>upload dokumen</title>
</head>
<body>
    
    <?php if(session('success')): ?>
        <div style="margin-top: 16px; color: green;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div style="margin-top: 16px; color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(url('get-lat-long')); ?>" method="post" enctype="multipart/form-data" style="margin: 24px">
        <?php echo csrf_field(); ?>
        <label style="margin-top: 8px" for="address">file excel untuk dicari latitude dan longitude nya</label> <br>
        <input style="margin-top: 8px" type="file" name="address" id="address"> <br>
        <button style="margin-top: 8px" type="submit">Submit</button>
    </form>
</body>
</html><?php /**PATH D:\freelance\leli\djikstra-map\resources\views/try/get_lat_long.blade.php ENDPATH**/ ?>