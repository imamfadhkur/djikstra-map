<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shortest Path</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <style>
        #map {
            height: 600px;
        }
    </style>
</head>
<body>
    <div id="map"></div>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
    <script>
        var map = L.map('map').setView([<?php echo e($coordinates[0]['lat']); ?>, <?php echo e($coordinates[0]['lng']); ?>], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19
        }).addTo(map);

        var waypoints = <?php echo json_encode($coordinates, 15, 512) ?>.map(function(waypoint) {
            return L.latLng(waypoint.lat, waypoint.lng);
        });

        L.Routing.control({
            waypoints: waypoints,
            routeWhileDragging: true,
            showAlternatives: false,
            createMarker: function(i, waypoint, n) {
                return L.marker(waypoint.latLng);
            }
        }).addTo(map);
    </script>
</body>
</html>
<?php /**PATH D:\freelance\leli\djikstra-map\resources\views/riset/path.blade.php ENDPATH**/ ?>